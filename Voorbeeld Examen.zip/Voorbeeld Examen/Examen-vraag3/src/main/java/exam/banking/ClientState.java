package exam.banking;

public enum ClientState {
	ACTIVE,DISABLED;
}
